#include <iostream>

int main() {
	int a=5;
	int x=a++;
	std::cout<<x<<std::endl;
	return 0;
}
